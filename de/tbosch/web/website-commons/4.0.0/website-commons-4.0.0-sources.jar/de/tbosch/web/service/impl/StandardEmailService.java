package de.tbosch.web.service.impl;

import jakarta.mail.internet.MimeMessage;
import de.tbosch.web.service.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMailMessage;
import org.springframework.stereotype.Service;

@Service
public class StandardEmailService implements EmailService {

    private static final Logger LOGGER = LoggerFactory.getLogger(StandardEmailService.class);

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private Environment env;

    @Override
    public boolean sendMeAnEmail(String name, String subject, String email, String message) {
        LOGGER.info("Send mail from {} to me with sender email {} and subject {}", new Object[] { name, email, subject });
        LOGGER.debug("... and message: {}", message);

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMailMessage mail = new MimeMailMessage(mimeMessage);
            mail.setSubject(subject);
            mail.setReplyTo(email);
            mail.setText("Nachricht aus dem Kontaktformular meiner Webseite:\n\nVon " + name + " (" + email + ")\n\n" + message);
            mail.setTo(env.getProperty("smtp.to"));
            mail.setFrom(env.getProperty("smtp.from"));
            mailSender.send(mail.getMimeMessage());
            return true;
        } catch (Exception var7) {
            LOGGER.error("Unable to send email", var7);
            return false;
        }
    }
}
