package de.tbosch.web.service;

public interface EmailService {

    boolean sendMeAnEmail(String name, String subject, String email, String message);
}
